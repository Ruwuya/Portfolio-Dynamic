export default function UsersPage(){
    return (
        <div className="users-container">
            <h1 className="users-title">Users page</h1>
            <div className="users-card">
                <p>Herro</p>
            </div>
        </div>
    );
}