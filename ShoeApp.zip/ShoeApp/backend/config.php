<?php
// Old database settings
define('DB_HOST', 'localhost');
define('DB_USER', 'Ruru');
define('DB_PASS', 'password');
define('DB_NAME', 'shoeapp_db');

/*
// Connecting to the schools database
define('DB_HOST', 'localhost');
define('DB_USER', 'rehi01_skp-dp_sde_dk');
define('DB_PASS', '4z3pz4py');
define('DB_NAME', 'rehi01_skp_dp_sde_dk');
*/
?>