<?php

// ===== CORS HEADERS =====
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Content-Type: application/json; charset=utf-8");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204); // No content, just say "OK, you may proceed"
    exit;
}

require_once __DIR__ . '/../db.php';

// ===== READ JSON BODY =====
$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

if (!is_array($data)) {
    echo json_encode([
        "status"  => "error",
        "message" => "Invalid JSON body"
    ]);
    exit;
}

$first = $conn->real_escape_string($data["first_name"] ?? "");
$last  = $conn->real_escape_string($data["last_name"] ?? "");
$age   = (int)($data["age"] ?? 0);
$email = $conn->real_escape_string($data["email"] ?? "");
$size  = (int)($data["shoesize_id"] ?? 0);

// Simple validation
if ($first === "" || $last === "" || $age <= 0 || $email === "" || $size <= 0) {
    echo json_encode([
        "status"  => "error",
        "message" => "Missing or invalid fields"
    ]);
    exit;
}

// ===== INSERT USER =====
$sql = "
    INSERT INTO users (first_name, last_name, age, email, shoesize_id)
    VALUES (
        '$first',
        '$last',
        $age,
        '$email',
        $size
    )
";

if ($conn->query($sql)) {
    echo json_encode(["status" => "success"]);
} else {
    http_response_code(500);
    echo json_encode([
        "status"  => "error",
        "message" => $conn->error
    ]);
}